package com.example.jpmorganapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FriendsFamily extends AppCompatActivity {

    String name1;
    String phone1;
    String name2;
    String name3;
    String phone2;
    String phone3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_family);
        configureBackButton();

//        //name1=Pop.getName1();
        TextView firstName;
        TextView secondName;
        TextView thirdName;
        firstName = findViewById(R.id.button6);
        secondName = findViewById(R.id.button7);
        thirdName = findViewById(R.id.button8);
        SharedPreferences sharedPreferences = getSharedPreferences(Pop.SHARED_PREFS, MODE_PRIVATE);
        name1 = sharedPreferences.getString(Pop.NAME1,"");
        phone1 = sharedPreferences.getString(Pop.PHONE1,"");
        name2 = sharedPreferences.getString(Pop.NAME2,"");
        phone2 = sharedPreferences.getString(Pop.PHONE2,"");
        name3 = sharedPreferences.getString(Pop.NAME3,"");
        phone3 = sharedPreferences.getString(Pop.PHONE3,"");
        firstName.setText(name1);
        secondName.setText(name2);
        thirdName.setText(name3);

    }
    public void OpenSettings(View view) {
        Intent settingsPage = new Intent(this, Pop.class);
        startActivity(settingsPage);
    }
    public void call1(View view) {
        String phoneNumber1 = "tel:" + phone1;
        Intent phoneIntent = new Intent(Intent.ACTION_CALL);
        phoneIntent.setData(Uri.parse(phoneNumber1));
        startActivity(phoneIntent);
    }
    public void call2(View view) {
        String phoneNumber1 = "tel:" + phone2;
        Intent phoneIntent = new Intent(Intent.ACTION_CALL);
        phoneIntent.setData(Uri.parse(phoneNumber1));
        startActivity(phoneIntent);
    }
    public void call3(View view) {
        String phoneNumber1 = "tel:" + phone3;
        Intent phoneIntent = new Intent(Intent.ACTION_CALL);
        phoneIntent.setData(Uri.parse(phoneNumber1));
        startActivity(phoneIntent);
    }
    private void configureBackButton(){
        Button backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
