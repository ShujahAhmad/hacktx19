package com.example.jpmorganapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Pop extends Activity {
    static String name1;
    static String phone1;
    static String name2;
    static String phone2;
    static String name3;
    static String phone3;

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String NAME1 = "name1";
    public static final String PHONE1 = "phone1";
    public static final String NAME2 = "name2";
    public static final String PHONE2 = "phone2";
    public static final String NAME3 = "name3";
    public static final String PHONE3 = "phone3";


    EditText nameInput1;
    EditText phoneInput1;
    EditText nameInput2;
    EditText phoneInput2;
    EditText nameInput3;
    EditText phoneInput3;

    Button doneButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.popwindow);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int) (width * 0.8), (int) (height * 0.8));
        nameInput1 = (EditText) findViewById(R.id.nameInput);
        phoneInput1 = (EditText) findViewById(R.id.phoneInput);
        nameInput2 = (EditText) findViewById(R.id.nameInput2);
        phoneInput2 = (EditText) findViewById(R.id.phoneInput2);
        nameInput3 = (EditText) findViewById(R.id.nameInput3);
        phoneInput3 = (EditText) findViewById(R.id.phoneInput3);

        doneButton = (Button) findViewById(R.id.doneButton);
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(Pop.this, Settings.class);
                name1 = nameInput1.getText().toString();
                phone1 = phoneInput1.getText().toString();
                name2 = nameInput2.getText().toString();
                phone2 = phoneInput2.getText().toString();
                name3 = nameInput3.getText().toString();
                phone3 = phoneInput3.getText().toString();

//                i.putExtra("Value",name1);
//                startActivity(i);
                saveData();
                finish();

            }

        });
        //startActivity(new Intent(this, MainActivity.class));

        //loadData();

    }

    public void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(NAME1, name1);
        editor.putString(PHONE1, phone1);
        editor.putString(NAME2, name2);
        editor.putString(PHONE2, phone2);
        editor.putString(NAME3, name3);
        editor.putString(PHONE3, phone3);

        editor.apply();
        startActivity(new Intent(this, MainActivity.class));

    }
}
