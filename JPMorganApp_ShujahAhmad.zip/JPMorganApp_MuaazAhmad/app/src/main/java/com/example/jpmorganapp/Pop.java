package com.example.jpmorganapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Pop extends Activity {
    static String name1;
    static String phone1;

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String NAME = "name";
    public static final String PHONE = "phone";

    private static String nameSave1;
    private static String phoneSave1;

    EditText nameInput;
    EditText phoneInput;

    Button doneButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.popwindow);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*0.8),(int)(height*0.6));
        nameInput = (EditText) findViewById(R.id.nameInput);
        phoneInput = (EditText) findViewById(R.id.phoneInput);

        doneButton = (Button) findViewById(R.id.doneButton);
        doneButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(Pop.this, Settings.class);
                name1 = nameInput.getText().toString();
                phone1 = phoneInput.getText().toString();

//                i.putExtra("Value",name1);
//                startActivity(i);
                saveData();
                finish();
            }
        });
        //loadData();

    }
    public void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(NAME, name1);
        editor.putString(PHONE,phone1);

        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        nameSave1 = sharedPreferences.getString(NAME,"");
        phoneSave1 = sharedPreferences.getString(PHONE,"");
    }

    public static String getName1() {

        if(name1=="") {

            return nameSave1;
        }
        return name1;
    }
    public static String getPhone1() {
        return phone1;
    }
}
