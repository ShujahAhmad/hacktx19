package com.example.jpmorganapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FriendsFamily extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_family);
    }
}
