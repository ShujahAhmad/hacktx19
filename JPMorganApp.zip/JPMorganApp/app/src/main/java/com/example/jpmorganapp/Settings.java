package com.example.jpmorganapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

//        setContentView(R.layout.popwindow);
//

    }
    public void updater(View view) {
        Intent popPage = new Intent(this, Pop.class);
        startActivity(popPage);
    }
}
