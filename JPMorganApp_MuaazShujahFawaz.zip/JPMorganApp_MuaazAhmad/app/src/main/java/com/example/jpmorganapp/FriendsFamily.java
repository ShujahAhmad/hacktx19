package com.example.jpmorganapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class FriendsFamily extends AppCompatActivity {

    String name1;
    String phone1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_family);

        //name1=Pop.getName1();
        TextView firstName;
        firstName = findViewById(R.id.button10);
        //firstName.setText(name1);
        SharedPreferences sharedPreferences = getSharedPreferences(Pop.SHARED_PREFS, MODE_PRIVATE);
        name1 = sharedPreferences.getString(Pop.NAME,"");
        phone1 = sharedPreferences.getString(Pop.PHONE,"");
        firstName.setText(name1);
    }
    public void call1(View view) {
        String phoneNumber1 = "tel:" + phone1;
        Intent phoneIntent = new Intent(Intent.ACTION_CALL);
        phoneIntent.setData(Uri.parse(phoneNumber1));
        startActivity(phoneIntent);
    }

}
